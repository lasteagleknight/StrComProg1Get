package week11Labs;

public class Paint {

}
