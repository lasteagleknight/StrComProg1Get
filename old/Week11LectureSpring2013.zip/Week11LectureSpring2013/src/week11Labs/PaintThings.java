package week11Labs;

public class PaintThings {

}
