package whileStuff;

public class WhileLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int count=0;
		
		while(count<=150){
			System.out.printf("Count is:%d\n", count);
			count++;
		}

	}

}
