package ifStuff;

public class ConditionalOperators { 
	
	public static void main(String[] args) {
		int x=9, y=15;
		
		System.out.println(x>y?"x is greater":"x is not greater");

	}

}
