
public class Problem2_14 {
	public static void main(String[]args){
		
		System.out.println("1, 2, 3, 4 "); // print numbers in a row using ln
		System.out.print("1, ");
		System.out.print("2, ");
		System.out.print("3, ");
		System.out.print("4 "); // printing numbers using print
		System.out.printf("\n%d, %d, %d, %d ", 1, 2, 3, 4); //printing numbers using f
	}
}
