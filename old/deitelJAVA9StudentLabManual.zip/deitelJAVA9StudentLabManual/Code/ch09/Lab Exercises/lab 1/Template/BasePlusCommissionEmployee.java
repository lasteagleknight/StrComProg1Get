// Exercise 9.3 solution: BasePlusCommissionEmployee.java
// BasePlusCommissionEmployee using composition.

public class BasePlusCommissionEmployee
{
   /* declare instance variable to satisfy the has-a relationship */
   private double baseSalary; // base salary per week

   // six-argument constructor
   public BasePlusCommissionEmployee( String first, String last, 
      String ssn, double sales, double rate, double salary )
   {
      /* construct the CommissionEmployee portion of this object */
      setBaseSalary( salary ); // validate and store base salary
   } // end six-argument BasePlusCommissionEmployee constructor
   
   // set first name
   public void setFirstName( String first )
   {
      /* set the first name of the composed CommissionEmployee object */
   } // end method setFirstName

   // return first name
   public String getFirstName()
   {
      /* return the first name of the composed CommissionEmployee object */
   } // end method getFirstName

   // set last name
   public void setLastName( String last )
   {
      /* set the last name of the composed CommissionEmployee object */
   } // end method setLastName

   // return last name
   public String getLastName()
   {
      /* return the last name of the composed CommissionEmployee object */
   } // end method getLastName

   // set social security number
   public void setSocialSecurityNumber( String ssn )
   {
      /* set the social security number of the composed CommissionEmployee object */
   } // end method setSocialSecurityNumber

   // return social security number
   public String getSocialSecurityNumber()
   {
      /* return the social security number of the composed CommissionEmployee
         object */
   } // end method getSocialSecurityNumber

   // set commission employee's gross sales amount
   public void setGrossSales( double sales )
   {
      /* set the gross sales of the composed CommissionEmployee object */
   } // end method setGrossSales

   // return commission employee's gross sales amount
   public double getGrossSales()
   {
      /* return the gross sales of the composed CommissionEmployee object */
   } // end method getGrossSales
   
   // set commission employee's rate
   public void setCommissionRate( double rate )
   {
      /* Set the commission rate of the composed CommissionEmployee object */
   } // end method setCommissionRate

   // return commission employee's rate
   public double getCommissionRate()
   {
      /* Return the commission rate of the composed CommissionEmployee object */
   } // end method getCommissionRate

   // set base-salaried commission employee's base salary
   public void setBaseSalary( double salary )
   {
      baseSalary = ( salary < 0.0 ) ? 0.0 : salary;
   } // end method setBaseSalary

   // return base-salaried commission employee's base salary
   public double getBaseSalary()
   {
      return baseSalary;
   } // end method getBaseSalary

   // calculate base-salaried commission employee's earnings
   public double earnings()
   {
      /* Calculate the earnings of this object using the earnings of the composed 
         CommissionEmployee object */
   } // end method earnings

   // return String representation of BasePlusCommissionEmployee
   public String toString()
   {
      /* Return a string consisting of the string representation of the composed 
         CommissionEmployee object along with the base salary */
   } // end method toString
} // end class BasePlusCommissionEmployee

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/