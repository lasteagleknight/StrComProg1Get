// Exercise 9.8 solution: Point.java
// Class Point definition

public class Point 
{
   private double x; // x coordinate
   private double y; // y coordinate
 
   // two-argument constructor
   public Point( double xCoordinate, double yCoordinate )
   {
      x = xCoordinate; // set x
      y = yCoordinate; // set y
   } // end two-argument Point constructor

   // return x
   public double getX()
   {
      return x;
   } // end method getX
   
   // return y
   public double getY()
   {
      return y;
   } // end method getY

   // return string representation of Point object
   public String toString()
   {
      return String.format( "( %.1f, %.1f )", getX(), getY() );
   } // end method toString
} // end class Point

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/