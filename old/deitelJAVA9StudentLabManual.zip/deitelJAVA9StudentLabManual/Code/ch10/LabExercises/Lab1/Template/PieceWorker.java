// Lab Exercise 1: PieceWorker.java
// PieceWorker class extends Employee.

public class PieceWorker extends Employee 
{
   /* declare instance variable wage */
   /* declare instance variable pieces */

   // five-argument constructor
   public PieceWorker( String first, String last, String ssn, 
      double wagePerPiece, int piecesProduced )
   {
      /* write code to initialize a PieceWorker */
   } // end five-argument PieceWorker constructor

   // set wage
   /* write a set method that validates and sets the PieceWorker's wage */

   // return wage
   /* write a get method that returns the PieceWorker's wage */

   // set pieces produced
   /* write a set method that validates and sets the number of pieces produced */

   // return pieces produced
   /* write a get method that returns the number of pieces produced */

   // calculate earnings; override abstract method earnings in Employee
   public double earnings()
   {
      /* write code to return the earnings for a PieceWorker */
   } // end method earnings

   // return String representation of PieceWorker object
   public String toString()
   {
      /* write code to return a string representation of a PieceWorker */
   } // end method toString
} // end class PieceWorker


/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
