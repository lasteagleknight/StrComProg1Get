// Programming Challenge 2: Rectangle.java
// Definition of class Rectangle

public class Rectangle
{
   // coordinates of the vertices.
   private double x1, y1;
   private double x2, y2;
   private double x3, y3;
   private double x4, y4;   

   // no-argument constructor
   public Rectangle()
   {
      setCoordinates( 1, 1, 1, 1, 1, 1, 1, 1 );
   } // end Rectangle no-argument constructor

   // constructor
   public Rectangle( double x1, double y1, double x2,
      double y2, double x3, double y3, double x4, double y4 )
   {
      setCoordinates( x1, y1, x2, y2, x3, y3, x4, y4 );
   } // end standard Rectangle constructor

   // check if coordinates are valid
   public void setCoordinates( double xInput1, double yInput1,
      double xInput2, double yInput2, double xInput3,
      double yInput3, double xInput4, double yInput4 )
   {
      x1 = ( xInput1 >= 0.0 && xInput1 <= 20.0 ? xInput1 : 1 );
      x2 = ( xInput2 >= 0.0 && xInput2 <= 20.0 ? xInput2 : 1 );
      x3 = ( xInput3 >= 0.0 && xInput3 <= 20.0 ? xInput3 : 1 );
      x4 = ( xInput4 >= 0.0 && xInput4 <= 20.0 ? xInput4 : 1 );
      y1 = ( yInput1 >= 0.0 && yInput1 <= 20.0 ? yInput1 : 1 );
      y2 = ( yInput2 >= 0.0 && yInput2 <= 20.0 ? yInput2 : 1 );
      y3 = ( yInput3 >= 0.0 && yInput3 <= 20.0 ? yInput3 : 1 );
      y4 = ( yInput4 >= 0.0 && yInput4 <= 20.0 ? yInput4 : 1 );

      if ( !isRectangle() )
         System.out.println( "This is not a rectangle" );
   } // end method setCoordinates

   // calculate distance between two points
   public double distance( double x1, double y1, double x2, double y2 )
   {
      return Math.sqrt( ( Math.pow( x1 - x2, 2 ) + Math.pow( y1 - y2, 2 ) ) );
   } // end method distance

   // check if coordinates specify a rectangle by determining if the
   // two diagonals are of the same length.
   public boolean isRectangle()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );
      double side3 = distance( x3, y3, x4, y4 );

      if ( ( side1 * side1 + side2 * side2 ) == 
         ( side2 * side2 + side3 * side3 ) )
         return true;
      else
         return false;
   } // end method isRectangle

   // check if rectangle is a square
   public boolean isSquare()
   {
      return ( getLength() == getWidth() );
   } // end method isSqaure

   // get length of rectangle
   public double getLength()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );

      return ( side1 > side2 ? side1 : side2 );
   } // end method getLength

   // get width of rectangle
   public double getWidth()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );

      return ( side1 < side2 ? side1 : side2 );
   } // end method getWidth

   // calculate perimeter
   public double perimeter()
   {
      return 2 * getLength() + 2 * getWidth();
   } // end method perimeter

   // calculate area
   public double area()
   {
      return getLength() * getWidth();
   } // end method area

   // convert to String
   public String toString()
   {
      return String.format( "%s: %.2f\n%s: %.2f\n%s: %.2f\n%s: %.2f",
         "Length", getLength(), "Width", getWidth(),
         "Perimeter", perimeter(), "Area", area() );
   } // end method toRectangleString
} // end class Rectangle

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/