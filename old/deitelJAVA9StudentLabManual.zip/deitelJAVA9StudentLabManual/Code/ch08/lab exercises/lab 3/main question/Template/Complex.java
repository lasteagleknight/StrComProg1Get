// Lab 3: Complex.java
// Definition of class Complex

public class Complex
{
   private double real;
   private double imaginary;

   // Initialize both parts to 0
   /* Write header for a no-argument constructor. */
   { 
      /* Write code here that calls the Complex constructor that takes 2 
         arguments and initializes both parts to 0 */
   } // end Complex no-argument constructor

   // Initialize real part to r and imaginary part to i
   /* Write header for constructor that takes two arguments-�real part r and
      imaginary part i. */
   {
      /* Write line of code that sets real part to r. */
      /* Write line of code that sets imaginary part to i. */
   }

   // Add two Complex numbers
   public Complex add( Complex right )
   {
      /* Write code here that returns a Complex number in which the real part is
         the sum of the real part of this Complex object and the real part of the
         Complex object passed to the method; and the imaginary part is the sum 
         of the imaginary part of this Complex object and the imaginary part of 
         the Complex object passed to the method. */
   }

   // Subtract two Complex numbers
   public Complex subtract( Complex right )
   {
      /* Write code here that returns a Complex number in which the real part is
         the difference between the real part of this Complex object and the real
         part of the Complex object passed to the method; and the imaginary part 
         is the difference between the imaginary part of this Complex object and
         the imaginary part of the Complex object passed to the method. */
   }

   // Return String representation of a Complex number
   public String toString() 
   { 
      return String.format( "(%.1f, %.1f)", real, imaginary );
   } // end method toComplexString;
} // end class Complex

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/