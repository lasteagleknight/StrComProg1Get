// Exercise 8.6 solution: SavingAccountTest.java
// Program that tests SavingAccount class

public class SavingAccountTest
{
   public static void main( String args[] )
   {
      SavingAccount saver1 = new SavingAccount( 2000 );
      SavingAccount saver2 = new SavingAccount( 3000 );
      SavingAccount.annualInterestRate = 0.04;

      System.out.println( "Monthly balances for one year at .04" );
      System.out.println( "Balances:" );
      
      System.out.printf( "%20s%10s\n", "Saver 1", "Saver 2" );
      System.out.printf( "%-10s%10s%10s\n", "Base",
         saver1.toString(), saver2.toString() );
      
      for ( int month = 1; month <= 12; month++ )
      {
         String monthLabel = String.format( "Month %d:", month );
         saver1.calculateMonthlyInterest();
         saver2.calculateMonthlyInterest();

         System.out.printf( "%-10s%10s%10s\n", monthLabel,
            saver1.toString(), saver2.toString() );
      } // end for

      SavingAccount.modifyInterestRate( .05 );
      saver1.calculateMonthlyInterest();
      saver2.calculateMonthlyInterest();
      
      System.out.println( "\nAfter setting interest rate to .05" );
      System.out.println( "Balances:" );
      System.out.printf( "%-10s%10s\n", "Saver 1", "Saver 2" );
      System.out.printf( "%-10s%10s\n",
         saver1.toString(),  saver2.toString() );
   } // end main
} // end class SavingAccountTest

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/