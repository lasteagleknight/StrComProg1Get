// Lab 1: Unique.java
// Reads in 5 unique numbers.
import java.util.Scanner;

public class Unique
{
   // gets 5 unique numbers from the user
   public void getNumbers()
   {
      Scanner input = new Scanner( System.in );

        /* Create an array of five elements*/ 
      int count = 0; // number of uniques read
      int entered = 0; // number of entered numbers
      
      while( entered < numbers.length )
      {
         System.out.print( "Enter number: " );
         /* Write code here to retrieve the input from the user */
         
         // validate the input
         /* Write an if statement that validates the input */  
         {
            // flags whether this number already exists
            boolean containsNumber = false;

            // increment number of entered numbers
            entered++;
            
            /* Compare the user input to the unique numbers in the array using a for 
               statement. If the number is unique, store new number */
            
            /* add the user input to the array only if the number is not already 
               in the array */
            if ( !containsNumber )
            {
               /* Write code to add the number to the array and increment 
                  unique items input */
            } // end if
            else 
               System.out.printf( "%d has already been entered\n",
                  number );
         } // end if
         else
            System.out.println( "number must be between 10 and 100" );
         
         // print the list of unique values
         /* Write code to output the contents of the array */
      } // end while      
   } // end method getNumbers
} // end class Unique

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/