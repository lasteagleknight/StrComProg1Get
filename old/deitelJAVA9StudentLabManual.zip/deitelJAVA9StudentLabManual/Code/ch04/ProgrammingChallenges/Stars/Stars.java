// Programming Challenge 2: Stars.java
// Program prints a checkerboard pattern.
public class Stars
{
   public static void main( String args[] )
   {
      int row = 1;

      while ( row <= 8 )
      {
         int column = 1;

         if ( row % 2 == 0 )
            System.out.print( " " );

         while ( column <= 8 )
         {
            System.out.print( "* " );
            column++;
         } // end inner while loop

         System.out.println();
         row++;
      } // end outer while loop
   } // end main
} // end class Stars

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/