// Lab 3: Largest.java
// Program determines and prints the largest of ten numbers.
import java.util.Scanner;

public class Largest
{
   // determine the largest of 10 numbers
   public void determineLargest()
   {
      Scanner input = new Scanner( System.in );
      
      int largest; // largest number
      int number; // user input
      int counter; // number of values entered

      /* write code to get the first integer and store it in variable largest */

      /* write code to initialize the number of integers entered */

      /* write code to loop until 10 numbers are entered */

      /* write code to prompt the user to enter a number and read tat number */

      /* write code to test whether the number entered is greater than the largest 
         if so, replace the value of largest with the entered number */

      /* write code to increment the number of integers entered */

      System.out.printf( "Largest number is %d\n", largest );
   } // end method determineLargest
} // end class Largest

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/