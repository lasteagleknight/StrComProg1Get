// Lab 2: Palindrome.java
// Program tests for a palindrome
import java.util.Scanner;

public class Palindrome
{
   // checks if a 5-digit number is a palindrome
   public void checkPalindrome()
   {
      Scanner input = new Scanner( System.in );
      
      int number; // user input number
      int digit1; // first digit
      int digit2; // second digit
      int digit4; // fourth digit
      int digit5; // fifth digit
      int digits; // number of digits in input

      number = 0;
      digits = 0;

      /* Write code that inputs a five-digit number. Display an error message
         if the number is not five digits. Loop until a valid input is received. */

      /* Write code that separates the digits in the five digit number. Use 
         division to isolate the left-most digit in the number, use a remainder 
         calculation to remove that digit from the number. Then repeat this 
         process. */

      /* Write code that determines whether the first and last digits are 
         identical and the second and Fourth digits are identical. Output 
         whether or not the original string is a palindrome. */

   } // end method checkPalindrome
} // end class Palindrome

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/