// Chapter 4 of Java How To Program
// Debugging Problem
import java.util.Scanner;

public class Temperature
{
   public static void main( String args[] )
   {
      int option;
      int degree1;
      int celsius1;
      int fahrenheit1;   
          
      Scanner input = new Scanner( System.in );

      option = 0; 
  
      While ( option != 3 )
      
         System.out.printf( "%s\n%s\n%s\n", "1 for Fahrenheit to Celsius", 
            "2 for Celsius to Fahrenheit", "3 to quit:" );
         option = input.nextDouble();
          
         System.out.println( "Enter the degrees in Fahrenheit: " );
         degree1 = input.nextDouble(); 
     
         celsius1 = ( degree1 - 32 ) * 5 / 9; 
         System.out.printf( "The temp in Celsius is %d\n", celsius1 ); 
          
         if ( option == 2 );
     
            System.out.println( "Enter the degrees in Celsius: " );
            degree1 = input.nextDouble(); 
     
            fahrenheit1 = ( degree1 * 9 / 5 ) + 32;
            System.out.printf( "The temp in Fahrenheit is %d\n", fahrenheit1 ); 
      } // end while loop
   } // end method Main
} // end class Temperature

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/