// Programming Challenge 2 Solution: Grid2JPanel.java
// Program draws 10x10 grid using draw().
import java.awt.geom.Rectangle2D;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class Grid2JPanel extends JPanel
{
   // draw grid
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );
      
      Graphics2D g2d = ( Graphics2D ) g;

      for ( int x = 30; x <= 300; x += 30 )
         for ( int y = 30; y <= 300; y += 30 )
            g2d.draw( new Rectangle2D.Double( x, y, 30, 30 ) );
   } // end method paintComponent
} // end class Grid2JPanel

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/