// Programming Challenge 1 Solution: Saver1JPanel.java
// Program simulates a simple screen saver
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class Saver1JPanel extends JPanel
{
   private Random generator = new Random();

   // draw lines
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // call superclass's paintComponent
      
      int x1, y1, x2, y2;
      
      // draw 100 random lines
      for ( int i = 0; i < 100; i++ ) 
      {
         x1 = generator.nextInt( 300 );
         y1 = generator.nextInt( 300 );
         x2 = generator.nextInt( 300 );
         y2 = generator.nextInt( 300 );

         g.setColor( new Color( generator.nextInt( 256 ),
            generator.nextInt( 256 ), generator.nextInt( 256 ) ) );
         g.drawLine( x1, y1, x2, y2 );
      } // end outer for

      repaint(); // repaint component
   } // end method paintComponent
} // end class Saver1JPanel

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/