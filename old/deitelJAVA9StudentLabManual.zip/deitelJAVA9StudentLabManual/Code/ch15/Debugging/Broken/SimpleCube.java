// Debugging Problem: SimpleCube.java
// Chapter 15
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import javax.swing.JPanel;

public class SimpleCube extends JPanel
{
   Random generator = new Random();

   public void paintComponent( g )
   {
      super.paintComponent( g );

      int x = generator.nextInt( 300 );
      int y = generator.nextInt( 300 );

      Graphics2D g2d = ( Graphics2D ) g;

      g2d.setColor( new Color( 
         generator.next(), generator.next(), generator.next() ) );
      g2d.drawRect( x, y, 210, 110 );

      // upper left line
      g2d.drawLine( x, y , x + 50, y - 50 );

      // upper right line
      g2d.drawLine( x + 210, y, x + 260, y - 50  );

      // lower right line
      g2d.drawLine( x + 210, y + 110, x + 260, y + 60 );

      // lower left line
      g2d.drawLine( x, y + 110, x + 50, y + 60 );

      int xUpperLeft = x + 50;
      int yUpperLeft = y - 50;

      int xUpperRight = x + 260;
      int yUpperRight = y - 50;

      int xLowerRight = x + 260;
      int yLowerRight = y + 60;

      int xLowerLeft = x + 50;
      int yLowerleft = y + 60;

      // close the rectangle
      g2d.drawLine( xUpperLeft, yUpperLeft, xUpperRight, yUpperRight );
      g2d.drawLine( xUpperRight, yUpperRight, xLowerRight, yLowerRight );
      g2d.drawLine( xLowerRight, yLowerRight, xLowerLeft, yLowerleft );
      g2d.drawLine( xLowerLeft, yLowerleft, xUpperLeft, yUpperLeft );

      //draw the text
      g2d.setFont( Font( "Font not specified", Font.BOLD, Font.ITALIC, 20 ) );
      g2d.drawString( " This Is A Simple Cube ", x + 5, y + 50 );
   }
} // end class SimpleCube


/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/