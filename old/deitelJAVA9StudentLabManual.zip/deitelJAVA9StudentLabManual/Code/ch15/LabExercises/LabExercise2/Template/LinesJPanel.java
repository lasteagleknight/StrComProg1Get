// Lab Exercise 2 Solution: LinesJPanel.java
// This program draws lines of different colors
import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.geom.Line2D;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import javax.swing.JPanel;

public class LinesJPanel extends JPanel 
{
   private Color colors[] = { Color.GREEN, Color.CYAN, Color.YELLOW, 
           Color.DARK_GRAY, Color.RED, Color.ORANGE,
           Color.GRAY, Color.PINK, Color.MAGENTA };

   // create 10 lines
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );
      setBackground( Color.BLACK ); // set JPanel background
      Random random = new Random(); // get random number generator
      
      // create 2D by casting g to Graphics 2D
      Graphics2D g2d = ( Graphics2D ) g;

      for ( int y = 60; y < 250; y += 20 ) 
      {
         // choose a random color from array
         /* Randomly choose an element of array colors and pass it to Graphics2D 
            method setColor to specify the drawing color */

         // choose a random thickness from 1-20
         /* Use Graphics2D method setStroke to randomly set the thickness of a line */

         // choose a random length and draw line
         /* Create a random length line and use Graphics2D method draw
            to display the line */
      } // end for
   } // end method paintComponent
} // end class LinesJPanel

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/