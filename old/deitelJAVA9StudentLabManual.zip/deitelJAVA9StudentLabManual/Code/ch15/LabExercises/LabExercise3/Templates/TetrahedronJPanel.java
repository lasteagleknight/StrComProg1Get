// Lab Exercise 3 Solution: TetrahedronJPanel.java
// Program draws a tetrahedron.
import java.awt.Color;
import java.awt.geom.GeneralPath;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class TetrahedronJPanel extends JPanel 
{
   // draw tetrahedron
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );

      /* Define a GeneralPath onject that represents a pyramid */
      
      /* Cast the Graphics reference received by paintComponent to a Graphics2D */

      /* Set the color of the pyramid using Graphics2D method setColor */

      /* Use method moveTo to specify the first point in the pyramid */

      /* Create a for loop that will access all the points in both arrays
         to create the pyramid in the GeneralPath object */

      /* Use method closePath to complete the pyramid */

      /* Use Graphics2D method draw to display the pyramid */
   } // end method paintComponent
} // end class TetrahedronJPanel


/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/