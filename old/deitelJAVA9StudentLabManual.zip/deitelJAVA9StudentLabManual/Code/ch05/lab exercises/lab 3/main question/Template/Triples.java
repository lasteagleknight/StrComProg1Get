// Lab 3: Triples.java
// Program calculates Pythagorean triples
public class Triples
{
   public static void main( String args[] )
   {
      // declare the three sides of a triangle
      int side1;
      int side2;
      int hypotenuse;

      /* Write loop for side1 to try the values 1-500. */ 

         /* Write loop for side2 to try the values 1-500. */  

            /* Write loop for hypotenuse to try the values 1-500 */   
              
               /* Write an if statement that determines whether the sum of the
                  two sides squared equals the hypotenuse squared. If this
                  condition is true display side1, side2 and hypotenuse. */
   } // end main
} // end class Triples

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/