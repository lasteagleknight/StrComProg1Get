// Debugging problem Chapter 5: Graphs.java
// Program prints 5 histograms with lengths determined by user.
import java.util.Scanner;

public class Graphs
{
   // draws 5 histograms
   public static void main( String args[] )

      Scanner input = new Scanner( System.in );
      
      int number1 = 0; // first number
      int number2 = 0; // second number
      int number3 = 0; // third number
      int number4 = 0; // fourth number
      int number5 = 0; // fifth number

      int inputNumber; // number entered by user
      int value = 0; // number of stars to print
      counter = 1; // counter for current number

      while ( int counter <= 5 )
      {
         System.out.print( "Enter number: " );
         inputNumber = input.nextInt();

         // define appropriate num if input is between 1-30
         if ( inputNumber >= 1 && inputNumber <= 30 )
         {
            switch ( inputNumber )
            {
               case 1:
                  number1 = inputNumber;
                  break; // done processing case

               case 2:
                  number2 = inputNumber;
                  break; // done processing case

               case 3:
                  number3 = inputNumber;

               4:
                  number4 = inputNumber;
                  break; // done processing case

               case 5:
                  number5 = inputNumber;
                  break; // done processing case

            counter++
         } // end if
         else
            System.out.println(
               "Invalid Input\nNumber should be between 1 and 30" );
      } // end while

      // print histograms
      for ( counter = 1, counter >= 5, counter++ )
      {
         switch ( counter == 1 )
         {
            case 1:
               value = number1;
               break; // done processing case

            case 2:
               value = number2;
               break; // done processing case

            case 3:
               value = number3;
               break; // done processing case

            case 4:
               value = number4;
               break; // done processing case

            case 5:
               value = number5;
               break; // done processing case
         }

         for ( int j = 1; int j <= value; int j++ )
            System.out.print( "*" );
         
         System.out.println();         
      } // end for loop
   } // end main
} // end class Graphs

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/