// Lab 1: Min.java
// Program finds the minimum of 3 numbers
import java.util.Scanner;

public class Min
{
   // find the minimum of three numbers
   public void findMinimum()
   {
      Scanner input = new Scanner( System.in );

      double one; // first number
      double two; // second number
      double three; // third number
      
      System.out.printf( "%s\n   %s\n   %s\n", 
         "Type the end-of-file indicator to terminate", 
         "On UNIX/Linux/Mac OS X type <ctrl> d then press Enter",
         "On Windows type <ctrl> z then press Enter" );
      System.out.print( "Or enter first number: " );
      
      while ( input.hasNext() )
      {
         one = input.nextDouble();

         /* Write code to get the remainder of the inputs and 
            convert them to double values */
         
         /* Write code to display the minimum of the three floating-point numbers */
         
         System.out.printf( "\n%s\n   %s\n   %s\n", 
            "Type the end-of-file indicator to terminate", 
            "On UNIX/Linux/Mac OS X type <ctrl> d then press Enter",
            "On Windows type <ctrl> z then press Enter" );
         System.out.print( "Or enter first number: " );
      } // end while
   } // end method findMinimum

   // determine the smallest of three numbers
   /* write the header for the minimum3 method */
   {
      // determine the minimum value
      return /* Write code to compute the minimum of the three numbers 
                using nested calls to Math.min */
   } // end method minimum3
} // end class Min

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/