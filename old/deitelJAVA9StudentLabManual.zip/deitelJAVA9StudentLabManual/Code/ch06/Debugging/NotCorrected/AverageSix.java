// Chapter 6 of Java How To Program
// Debugging Problem
import java.util.Scanner;

public class AverageSix
{
   public void getGrades()
   {
      Scanner input = new Scanner( System.in );

      System.out.println( "Please enter the number of students you wish to average" );  
      int students2 = input.nextInt();

      int NumOfStudents = students2; 
      int counter = 1;  
      double total = 0, previousNumber = 0, newMaximum = 0, newMinimum = 0; 

      while ( students2 != 0 ) 
      {    
         System.out.println( "Please enter a grade" ); 
         double givenNum = input.nextDouble();
         total = total + givenNum; 

         if ( counter == 1 ) 
         {
            previousNumber = givenNum; 
            newMinimum = givenNum; 
         } // end if

         if ( newMaximum < givenNum )
            newMaximum = maximum( previousNumber, givenNum );

         if ( newMinimum > givenNum )
            newMinimum = minimum( previousNumber, givenNum ); 

         students2--;
         counter++; 
         previousNumber = givenNum;
      } // end while

      double average1 = average( total, NumOfStudents ); 

      System.out.printf( "The maximum: %.2f\nThe average: %.2f\nThe minimum: %.2f\n", 
         newMaximum, average1, newMinimum);
   } // end method getGrades
} // end class AverageSix

public double average( double x, y );
{
   return x / y; 
} // end method average

public double maximum( double x, double y )
{
   Math.max( x, y ); 
} // end method maximum

public double minimum( double x, int y )
{
   return min( x, y );
} // end method minimum

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/