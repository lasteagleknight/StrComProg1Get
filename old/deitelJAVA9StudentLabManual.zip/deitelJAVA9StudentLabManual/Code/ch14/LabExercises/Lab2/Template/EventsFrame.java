// Lab Exercise 2 Solution: EventsFrame.java
// Program displays events that occur during execution.
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

public class EventsFrame extends JFrame implements ActionListener, 
   ItemListener, MouseListener, MouseMotionListener, 
   KeyListener, ListSelectionListener 
{
   private JPanel panel1;
   private JScrollPane scrollPane;
   private JTextArea outputJTextArea;
   private JComboBox comboBox;
   private JRadioButton radioButton;
   private JList list;
   private JButton clearJButton;

   private String names[] = { 
      "Anteater", "Caterpillar", "Centipede", "Fire Fly" };

   // set up GUI and register event handlers
   public EventsFrame()
   {
      super( "Events" );

      // create GUI components
      outputJTextArea = new JTextArea( 10, 30 );
      outputJTextArea.setLineWrap( true );
      outputJTextArea.setEditable( false );
      outputJTextArea.setBackground( Color.WHITE );
      outputJTextArea.setForeground( Color.BLACK );

      // add the output area to a scroll pane 
      // so the user can scroll the output
      /* Write a statement that attaches the output JTextArea to a JScrollPane */

      // comboBox listens for item and key events
      comboBox = new JComboBox( names );
      /* Write a statement that registers an ItemListener for this JComboBox */
      /* Write a statement that registers a KeyListener for this JComboBox */

      // radioButton listens for action events
      radioButton = new JRadioButton( "Select Me", false );
      /* Write a statement that registers an ActionListener for
         this JRadioButton */

      // list listens for list selection events
      list = new JList( names );
      list.addListSelectionListener( this );

      // clear button for clearing the output area
      clearJButton = new JButton( "Clear" );
      clearJButton.addActionListener( 
         /* Write code that defines an anonymous inner class that
            will clear the output JTextArea when the clear button is clicked */
      ); // end call to addActionListener

      // application listens to its own key and mouse events
      /* Write code that registers a MouseListener
         and a MouseMotionListener for the Events JFrame */

      panel1 = new JPanel();
      panel1.add( comboBox );
      panel1.add( radioButton );
      panel1.add( list );
      panel1.add( clearJButton );

      // add components to container
      setLayout( new BorderLayout() );
      add( scrollPane, BorderLayout.CENTER );
      add( panel1, BorderLayout.SOUTH );
   } // end EventsFrame constructor

   // ActionListener event handlers
   /* Implement the ActionListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // ItemListener event handlers
   /* Implement the ItemListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // MouseListener event handlers
   /* Implement the MouseListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // MouseMotionListener event handlers
   /* Implement the MouseMotionListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // KeyListener event handlers
   /* Implement the KeyListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // ListSelectionListener event handlers
   /* Implement the ListSelectionListener interface. Display the string representation
      of each event that occurs in the output JTextArea */

   // display event occurred to output
   public void display( String eventName, Object event )
   {
      outputJTextArea.append( String.format( "%s occurred\n%S\n\n",
         eventName, event.toString() ) );
   } // end method display
} // end class EventsFrame

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/