/* Chapter 2 of Java How to Program: Seventh Edition
   Debugging Problem /

public class Arithmetic
{
import java.util.Scanner;
    
   public static void main( String args[] )
   {
      Scanner input = new Scanner( System.in );  
      int num2
      int num3
      int sum
      int product
      int average

      System.out.println( "Enter first integer:" );
      num1 == input.nextInt();

      System.out.println( "Enter second integer:" );
      num2 == input.nextInt();
      
      System.out.println( "Enter third integer: );
      num3 == input.nextInt();
      
      sum = num1 + num2 + num3;
      product = num1 * num2 * num3;
      average = ( num1 + num2 + num3 ) / 3;
      
      System.out.println( "The sum is %d\nThe product is %d\nThe average is %d", sum, 
         product, average );
   }
} // end class Arithmetic

/**************************************************************************
 * (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/