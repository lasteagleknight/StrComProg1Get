package exercises3_15;


public class DateTest {
	
	public static void main(String[]args){
		
		Date date1 = new Date(18,6,1984);
		
		date1.displayDate();
		
		//System.out.println(date1.getDay());
	}

}
