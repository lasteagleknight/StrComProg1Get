
public class Knife extends Object {
	
	public Knife(String name){//weppon for player
		super(name);
	}

	@Override
	public void examine() {
		// TODO Auto-generated method stub
		
	}

}
