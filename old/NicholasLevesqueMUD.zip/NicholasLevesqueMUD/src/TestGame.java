
public class TestGame {

	public static void main(String[] args) {
		Game.game();
	}
}
