
public class gameTest {
	
	public static void main(String[] args){
		Game.game();//runs game.
	}

}
