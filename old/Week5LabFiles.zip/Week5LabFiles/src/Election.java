
public class Election {

}
