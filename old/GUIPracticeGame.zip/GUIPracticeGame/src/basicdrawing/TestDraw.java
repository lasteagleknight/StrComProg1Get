package basicdrawing;

public class TestDraw {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DrawFrame tester=new DrawFrame();

	}

}
