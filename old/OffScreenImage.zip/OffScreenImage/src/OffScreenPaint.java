import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;


public class OffScreenPaint {
	public static void main(String[] a) {
		MyFrame canvas=new MyFrame();		
	}
}
